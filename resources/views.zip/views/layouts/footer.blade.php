<footer class="bg-gray-100 text-center text-sm text-gray-600 py-6 mt-12">
    <div class="max-w-5xl mx-auto px-4">
        &copy; {{ date('Y') }} Zawajnet. جميع الحقوق محفوظة.
    </div>
</footer>
